import UseCases from '../UseCases';

export default function UseCasesExample() {
  return <UseCases />;
}
